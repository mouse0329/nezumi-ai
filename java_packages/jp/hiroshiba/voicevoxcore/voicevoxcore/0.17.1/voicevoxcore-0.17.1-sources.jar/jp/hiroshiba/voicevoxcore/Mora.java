package jp.hiroshiba.voicevoxcore;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import jakarta.annotation.Nonnull;
import jakarta.annotation.Nullable;
import jp.hiroshiba.voicevoxcore.exceptions.InvalidQueryException;

/**
 * モーラ（子音＋母音）ごとの情報。
 *
 * <p>このクラスは不正な状態を表現しうる。どのような状態が不正なのかについては{@link #validate}を参照。このクラスを使う関数は、不正な状態に対して{@link
 * InvalidQueryException}をスローする。
 *
 * <p>コンストラクト時には、不正な状態であるかの検証は行われない。外部からのデータが不正でないことを確かめるには、コンストラクト後に{@code validate()}を用いる必要がある。
 *
 * <pre>{@code
 * Mora mora = (new Gson()).fromJson(json, Mora.class);
 * mora.validate();
 * }</pre>
 *
 * <p>Gsonにおいてはフィールド名はsnake_caseとなる。<a
 * href="https://github.com/VOICEVOX/voicevox_core/blob/main/docs/guide/user/serialization.md"
 * target="_blank">データのシリアライゼーション</a>を参照。
 *
 * <p>Gsonについては将来的には <a href="https://github.com/VOICEVOX/voicevox_core/issues/984"
 * target="_blank">Jacksonに切り替わる予定</a> 。
 */
public final class Mora implements Cloneable {
  /** 文字。 */
  @SerializedName("text")
  @Expose
  @Nonnull
  @SuppressWarnings("NullableProblems")
  public String text;

  /** 子音の音素。 */
  @SerializedName("consonant")
  @Expose
  @Nullable
  public String consonant;

  /** 子音の音長。 */
  @SerializedName("consonant_length")
  @Expose
  public java.lang.Double consonantLength;

  /** 母音の音素。 */
  @SerializedName("vowel")
  @Expose
  @Nonnull
  @SuppressWarnings("NullableProblems")
  public String vowel;

  /** 母音の音長。 */
  @SerializedName("vowel_length")
  @Expose
  public double vowelLength;

  /** 音高。 */
  @SerializedName("pitch")
  @Expose
  public double pitch;

  public Mora() {
    this.text = "";
    this.consonant = null;
    this.consonantLength = null;
    this.vowel = "";
    this.vowelLength = 0.0;
    this.pitch = 0.0;
  }

  /**
   * このインスタンスが不正であるときエラーを返す。
   *
   * <p>不正であるとは、{@code @throws}で示す条件を満たすことである。
   *
   * @throws InvalidQueryException 次のうちどれかを満たす場合
   *     <ul>
   *       <li>JSONへのシリアライズが不可。
   *           <ul>
   *             <li>{@link #consonantLength}がNaNもしくは±infinity。
   *             <li>{@link #vowelLength}がNaNもしくは±infinity。
   *             <li>{@link #pitch}がNaNもしくは±infinity。
   *           </ul>
   *       <li><a
   *           href="https://voicevox.github.io/voicevox_core/apis/rust_api/voicevox_core/struct.Mora.html">Rust
   *           APIの{@code Mora}型</a>としてデシリアライズ不可。
   *           <ul>
   *             <li>{@link #consonant}が子音以外の音素であるか、もしくは音素として不正。
   *             <li>{@link #consonantLength}が負。
   *             <li>{@link #vowel}が子音であるか、もしくは音素として不正。
   *             <li>{@link #vowelLength}が負。
   *           </ul>
   *       <li>{@link #consonant}と{@link #consonantLength}の有無が不一致。
   *     </ul>
   */
  public void validate() {
    rsValidate();
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof Mora)) {
      return false;
    }
    Mora other = (Mora) obj;
    return text.equals(other.text)
        && consonant.equals(other.consonant)
        && vowel.equals(other.vowel)
        && vowelLength == other.vowelLength
        && pitch == other.pitch;
  }

  @Override
  public Mora clone() {
    Mora ret = new Mora();
    ret.text = text;
    ret.consonant = consonant;
    ret.consonantLength = consonantLength;
    ret.vowel = vowel;
    ret.vowelLength = vowelLength;
    ret.pitch = pitch;
    return ret;
  }

  private native void rsValidate();
}
